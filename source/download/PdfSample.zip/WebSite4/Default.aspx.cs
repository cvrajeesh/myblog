﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FileStream fs = new FileStream(Server.MapPath("Sample.pdf"),FileMode.Open);

        long size = fs.Length;

        Byte[] buffer = new Byte[size];
        fs.Read(buffer, 0, (int)size);
        fs.Close();

        Response.ContentType = "application/pdf";
        Response.OutputStream.Write(buffer, 0, (int)size);
        Response.Flush();
        Response.Close();

    }
}
