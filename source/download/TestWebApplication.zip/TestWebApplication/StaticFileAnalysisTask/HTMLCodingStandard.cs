﻿
using System.Linq;
using HtmlAgilityPack;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;

namespace StaticFileAnalysisTask
{
    /// <summary>
    /// Custom MSBuild task which analyse the HTML code validation.
    /// </summary>
    public class HTMLCodingStandard : Task
    {
        #region Private fields

        /// <summary>
        /// Variable that holds the status of this task execution.
        /// </summary>
        private bool _success;

        #endregion

        #region Public properties

        /// <summary>
        /// Gets or sets the source file list.
        /// </summary>
        /// <value>The source file list.</value>
        [Required]
        public ITaskItem[] SourceFiles { get; set; }

        /// <summary>
        /// Gets or sets the list of files to be excluded.
        /// </summary>
        /// <value>The excluded files.</value>
        public ITaskItem[] ExcludeFiles { get; set; }

        #endregion

        /// <summary>
        /// Executes this task.
        /// </summary>
        /// <returns><c>true</c> if task executed successfully; Otherwise, <c>false</c>.</returns>
        public override bool Execute()
        {
            this._success = true;
            
            foreach (ITaskItem current in SourceFiles)
            {
                // If the items is in the exluded list, then skip 
                if(this.IsInExlcudedList(current))
                {
                    continue;
                }

                string path = current.ItemSpec;
                if (path.EndsWith(".aspx"))
                {
                    this.ValidateFile(path);
                }
            }
            return this._success;
        }

        /// <summary>
        /// Method that is responsible for validating the file.
        /// </summary>
        /// <param name="path">The full path to the file.</param>
        private void ValidateFile(string path)
        {
            HtmlDocument htmlDocument = new HtmlDocument();
            htmlDocument.Load(path);
            HtmlNode node = htmlDocument.DocumentNode.SelectSingleNode("//html");
            if(node != null)
            {
                if(!node.Attributes.Contains("dir"))
                {
                    this.BuildEngine.LogErrorEvent(new BuildErrorEventArgs(
                        "Invalid HTML coding standard", 
                        "SFAT-HTML-1", 
                        path, 
                        node.Line, 
                        node.LinePosition, 
                        node.LinePosition, 
                        node.LinePosition + node.OuterHtml.Length,
                        "SFAT-HTML-1: Direction(dir) tag is missing",
                        null,
                        "HTMLCodingStandardTask"
                        ));
                    this._success = false;
                }

              
            }
        }

        /// <summary>
        /// Determines whether an item is in the excluded list.
        /// </summary>
        /// <param name="taskItem">The task item which needs to checked.</param>
        /// <returns>
        /// 	<c>true</c> if item is in exlcuded list; otherwise, <c>false</c>.
        /// </returns>
        private bool IsInExlcudedList(ITaskItem taskItem)
        {
            if(this.ExcludeFiles == null)
            {
                return false;
            }

            return this.ExcludeFiles.Any(x => x.ItemSpec == taskItem.ItemSpec);
        }
    }
}
