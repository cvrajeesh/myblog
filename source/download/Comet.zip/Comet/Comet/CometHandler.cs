﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;

namespace Comet
{
    public class CometHandler : IHttpHandler
    {
        public static string Delimiter = "|";

        #region IHttpHandler Members

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {

            context.Response.Buffer = false;

            while (true)
            {
                context.Response.ClearContent();
                context.Response.Write(Delimiter + DateTime.Now.ToString("HH:mm:ss.FFF"));
                context.Response.Flush();

                // Suspend the thread for 1/2 a second
                System.Threading.Thread.Sleep(500);
            }

            // Yes I know we'll never get here, it's just hard not to include it!
            context.Response.End();
        }

        #endregion
    }
}
