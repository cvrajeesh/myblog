﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Profiler.cs" company="MyCompany">
//   All rights reserved
// </copyright>
// <summary>
//   Defines the Profiler type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ProfilingSample
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    /// <summary>
    /// Helper class that wraps the timer based functionalities.
    /// </summary>
    internal static class Profiler
    {
        /// <summary>
        /// Lock object.
        /// </summary>
        private static readonly object SyncLock = new object();

        /// <summary>
        /// Variable that tracks the time.
        /// </summary>
        private static readonly Dictionary<int, Stack<long>> ProfilePool;

        /// <summary>
        /// Initializes static members of the <see cref="Profiler"/> class. 
        /// </summary>
        static Profiler()
        {
            ProfilePool = new Dictionary<int, Stack<long>>();
        }

        /// <summary>
        /// Starts this timer.
        /// </summary>
        public static void Start()
        {
            lock (SyncLock)
            {
                int currentThreadId = Thread.CurrentThread.ManagedThreadId;
                if (ProfilePool.ContainsKey(currentThreadId))
                {
                    ProfilePool[currentThreadId].Push(Environment.TickCount);
                }
                else
                {
                    var timerStack = new Stack<long>();
                    timerStack.Push(DateTime.UtcNow.Ticks);
                    ProfilePool.Add(currentThreadId, timerStack);
                }
            }
        }

        /// <summary>
        /// Stops timer and calculate the execution time.
        /// </summary>
        /// <returns>Execution time in milli seconds</returns>
        public static int Stop()
        {
            lock (SyncLock)
            {
                long currentTicks = DateTime.UtcNow.Ticks;
                int currentThreadId = Thread.CurrentThread.ManagedThreadId;

                if (ProfilePool.ContainsKey(currentThreadId))
                {
                    long ticks = ProfilePool[currentThreadId].Pop();
                    if (ProfilePool[currentThreadId].Count == 0)
                    {
                        ProfilePool.Remove(currentThreadId);
                    }

                    var timeSpan = new TimeSpan(currentTicks - ticks);

                    return (int)timeSpan.TotalMilliseconds;
                }
            }

            return 0;
        }
    }

}
