﻿using System.Configuration;
using System.Text;
using log4net;

namespace ProfilingSample
{
    /// <summary>
    /// Logger helper.
    /// </summary>
    public class LoggerHelper
    {
        /// <summary>
        /// Static instance of ILogger.
        /// </summary>
        private static ILog logger;

        /// <summary>
        /// Initializes static members of the <see cref="LoggerHelper"/> class. 
        /// </summary>
        static LoggerHelper()
        {
            log4net.Config.XmlConfigurator.Configure();
            logger = LogManager.GetLogger(typeof(Program));
        }

        /// <summary>
        /// Logs the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        public static void Log(string message)
        {
            string enableProfiling = ConfigurationManager.AppSettings["EnableProfiling"];
            if (string.IsNullOrEmpty(enableProfiling) || enableProfiling.ToLowerInvariant() == "true")
            {
                logger.Debug(message);
            }
        }

        /// <summary>
        /// Logs the specified method name.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="url">The URL to log.</param>
        /// <param name="executionFlowMessage">The execution flow message.</param>
        /// <param name="actualMessage">The actual message.</param>
        public static void Log(string methodName, string url, string executionFlowMessage, string actualMessage)
        {
            Log(ConstructLog(methodName, url, executionFlowMessage, actualMessage));
        }

        /// <summary>
        /// Logs the specified method name.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="url">The URL to log.</param>
        /// <param name="executionFlowMessage">The execution flow message.</param>
        /// <param name="actualMessage">The actual message.</param>
        /// <param name="executionTime">The execution time.</param>
        public static void Log(string methodName, string url, string executionFlowMessage, string actualMessage, int executionTime)
        {
            Log(ConstructLog(methodName, url, executionFlowMessage, actualMessage, executionTime));
        }

        /// <summary>
        /// Constructs the log.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="url">The URL to be logged.</param>
        /// <param name="executionFlowMessage">The execution flow message.</param>
        /// <param name="actualMessage">The actual message.</param>
        /// <returns>Formatted string.</returns>
        private static string ConstructLog(string methodName, string url, string executionFlowMessage, string actualMessage)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrEmpty(methodName))
            {
                sb.AppendFormat("MethodName : {0}, ", methodName);
            }

            if (!string.IsNullOrEmpty(url))
            {
                sb.AppendFormat("Url : {0}, ", url);
            }

            if (!string.IsNullOrEmpty(executionFlowMessage))
            {
                sb.AppendFormat("ExecutionFlowMessage : {0}, ", executionFlowMessage);
            }

            if (!string.IsNullOrEmpty(actualMessage))
            {
                sb.AppendFormat("ActualMessage : {0}, ", actualMessage);
            }

            string message = sb.ToString();

            message = message.Remove(message.Length - 2);

            return message;
        }

        /// <summary>
        /// Constructs the log.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="url">The URL to be logged.</param>
        /// <param name="executionFlowMessage">The execution flow message.</param>
        /// <param name="actualMessage">The actual message.</param>
        /// <param name="executionTime">The execution time.</param>
        /// <returns>Formatted string.</returns>
        private static string ConstructLog(string methodName, string url, string executionFlowMessage, string actualMessage, int executionTime)
        {
            var sb = new StringBuilder();

            sb.Append(ConstructLog(methodName, url, executionFlowMessage, actualMessage));
            sb.AppendFormat(", ExecutionTime : {0}", executionTime);

            return sb.ToString();
        }
    }
}
