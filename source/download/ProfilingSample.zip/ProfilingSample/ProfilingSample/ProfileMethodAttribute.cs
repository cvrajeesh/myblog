﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ProfileMethodAttribute.cs" company="MyCompany">
//   All rights reserved
// </copyright>
// <summary>
//   Attribute which could be used to profile a method.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ProfilingSample
{
    using System;
    using System.Web;
    using PostSharp.Laos;

    /// <summary>
    /// Attribute which could be used to profile a method.
    /// </summary>
    [Serializable]
    public class ProfileMethodAttribute : OnMethodBoundaryAspect 
    {
        #region Private fields
        
        /// <summary>
        /// Name of the method.
        /// </summary>
        private string _methodName;

        /// <summary>
        /// Current request url.
        /// </summary>
        private string _url; 

        #endregion
        #region Public Properties

        /// <summary>
        /// Gets or sets a value indicating whether to exclude method name.
        /// </summary>
        /// <value><c>true</c> if method name is excluded; otherwise, <c>false</c>.</value>
        public bool ExcludeMethodName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether to include Url, if it is running in Web scenario.
        /// </summary>
        /// <value><c>true</c> if Url is included; otherwise, <c>false</c>.</value>
        public bool IncludeUrl { get; set; }

        /// <summary>
        /// Gets or sets the entry message.
        /// </summary>
        /// <value>The entry message.</value>
        public string EntryMessage { get; set; }

        /// <summary>
        /// Gets or sets the exit message.
        /// </summary>
        /// <value>The exit message.</value>
        public string ExitMessage { get; set; }

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; } 

        #endregion

        /// <summary>
        /// Method executed <b>before</b> the body of methods to which this aspect is applied.
        /// </summary>
        /// <param name="eventArgs">Event arguments specifying which method
        /// is being executed, which are its arguments, and how should the execution continue
        /// after the execution of <see cref="M:PostSharp.Laos.IOnMethodBoundaryAspect.OnEntry(PostSharp.Laos.MethodExecutionEventArgs)"/>.</param>
        /// <remarks>
        /// If the aspect is applied to a constructor, the current method is invoked
        /// after the <b>this</b> pointer has been initialized, that is, after
        /// the base constructor has been called.
        /// </remarks>
        public override void OnEntry(MethodExecutionEventArgs eventArgs)
        {
            this._methodName = this.ExcludeMethodName ? string.Empty : eventArgs.Method.Name;
            this._url = this.IncludeUrl ? string.Empty : (HttpContext.Current == null) ? string.Empty : HttpContext.Current.Request.Url.ToString();

            LoggerHelper.Log(this._methodName, this._url, this.EntryMessage, this.Message);
            Profiler.Start();
        }

        /// <summary>
        /// Method executed <b>after</b> the body of methods to which this aspect is applied,
        /// even when the method exists with an exception (this method is invoked from
        /// the <b>finally</b> block).
        /// </summary>
        /// <param name="eventArgs">Event arguments specifying which method
        /// is being executed and which are its arguments.</param>
        public override void OnExit(MethodExecutionEventArgs eventArgs)
        {
            int count = Profiler.Stop();
            LoggerHelper.Log(this._methodName, this._url, this.EntryMessage, this.Message, count);
        }
    }
   
}
