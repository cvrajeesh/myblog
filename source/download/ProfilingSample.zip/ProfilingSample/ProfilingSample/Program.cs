﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="MyCompany">
//   All rights reserved
// </copyright>
// <summary>
//   Defines the Program type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Threading;

namespace ProfilingSample
{
    /// <summary>
    /// Main class that runs the program.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Mains the specified args.
        /// </summary>
        /// <param name="args">Arguments that are passed via commandline.</param>
        public static void Main(string[] args)
        {
            var sampleApp = new SampleApp();
            sampleApp.SimpleMethod();
            try
            {
                sampleApp.MethodWithException();
            }
            catch (Exception)
            {
                
            }

            Console.WriteLine("Press enter to exit");
            Console.ReadLine();
            
        }
    }

    /// <summary>
    /// Sample class for testing the profiling functionality.
    /// </summary>
    public class SampleApp
    {
        [ProfileMethod()]
        public void SimpleMethod()
        {
            Thread.Sleep(5000);
        }

        [ProfileMethod()]
        public void MethodWithException()
        {
            Thread.Sleep(5000);
        }
    }
}
