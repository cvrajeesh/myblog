﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Markup;

namespace SimpleControl
{
    public class HostingSurface : Control
    {
        private Canvas hostingCanvas;
        Ellipse circle;

        public double Radius 
        {
            get
            {
                return circle.Width;
            }
            set
            {
                circle.Width = value;
                circle.Height = value;
            }
        }

        public HostingSurface()
        {
            System.IO.Stream stream =
                this.GetType().Assembly.GetManifestResourceStream("SimpleControl.HostingSurface.xaml");
            hostingCanvas =
                this.InitializeFromXaml(new System.IO.StreamReader(stream).ReadToEnd()) as Canvas;


            //Load the SimpleCircle.xaml file
            System.IO.Stream circleStream =
                this.GetType().Assembly.GetManifestResourceStream("SimpleControl.SimpleCircle.xaml");
            circle =
                XamlReader.Load(new System.IO.StreamReader(circleStream).ReadToEnd()) as Ellipse;

            hostingCanvas.Children.Add(circle);

        }
    }
}
