package com.plugai.android.livewallpapers;

import android.graphics.Canvas;

public interface Renderable {
	void render(Canvas canvas);
}
